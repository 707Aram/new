<?php
$emailku = 'rpm91167@hawkmail.hacc.edu'; // GANTI EMAIL KAMU DISINI
?>